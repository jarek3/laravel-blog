<div class="col-xs-9">
    <div class="box">
        <div class="box-body ">

            <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                <?php echo Form::label('name'); ?>

                <?php echo Form::text('name', null, ['class' => 'form-control']); ?>


                <?php if($errors->has('name')): ?>
                    <span class="help-block"><?php echo e($errors->first('name')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('slug') ? 'has-error' : ''); ?>">
                <?php echo Form::label('slug'); ?>

                <?php echo Form::text('slug', null, ['class' => 'form-control']); ?>


                <?php if($errors->has('slug')): ?>
                    <span class="help-block"><?php echo e($errors->first('slug')); ?></span>
                <?php endif; ?>
            </div>
        </div>
        <!-- /.box-body -->
        <div class="box-footer">
            <button type="submit" class="btn btn-primary"><?php echo e($tag->exists ? 'Update' : 'Save'); ?></button>
            <a href="<?php echo e(route('backend.tags.index')); ?>" class="btn btn-default">Cancel</a>
        </div>
    </div>
    <!-- /.box -->
</div>
<?php /**PATH C:\xampp\htdocs\laravel-blog\resources\views/backend/tags/form.blade.php ENDPATH**/ ?>