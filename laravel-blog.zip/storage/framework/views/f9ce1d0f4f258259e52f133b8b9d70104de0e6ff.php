<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-8">
            <?php if(!$posts->count()): ?>
                <div class="alert alert-warning">
                    <p>Nothing Found</p>
                </div>
            <?php else: ?>

                <?php echo $__env->make('blog.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <article class="post-item">
            <?php if($post->image_url): ?>
                <div class="post-item-image">
                    <a href="<?php echo e(route('blog.show', $post->slug)); ?>">
                        <img src="<?php echo e($post->image_url); ?>" alt="">
                    </a>
                </div>
            <?php endif; ?>
                    <div class="post-item-body">
                        <div class="padding-10">
                            <h2><a href="<?php echo e(route('blog.show', $post->slug)); ?>"><?php echo e($post->title); ?></a></h2>
                            <?php echo $post->excerpt_html; ?>

                        </div>

                        <div class="post-meta padding-10 clearfix">
                            <div class="pull-left">
                                <ul class="post-meta-group">
                                    <li><i class="fa fa-user"></i><a href="<?php echo e(route('author', $post->author->slug)); ?>"><?php echo e($post->author->name); ?></a></li>
                                    <li><i class="fa fa-clock-o"></i><time> <?php echo e($post->date); ?></time></li>
                                    <li><i class="fa fa-tags"></i><a href="<?php echo e(route('category', $post->category->slug)); ?>"><?php echo e($post->category->title); ?></a></li>

                                    <li><i class="fa fa-tag"></i><?php echo $post->tags_html; ?></li>

                                    <li><i class="fa fa-comments"></i><a href="<?php echo e(route('blog.show', $post->slug)); ?>#post-comments"><?php echo e($post->commentsNumber()); ?></a></li>
                                </ul>
                            </div>
                            <div class="pull-right">
                                <a href="<?php echo e(route('blog.show', $post->slug)); ?>">Continue Reading &raquo;</a>
                            </div>
                        </div>
                    </div>
                </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <nav>

            <?php echo e($posts->appends(request()->only(['term', 'month', 'year']))->links()); ?>


            </nav>
        </div>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-blog\resources\views/blog/index.blade.php ENDPATH**/ ?>