<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
           <div class="col-md-12 page-not-found">
              <h2>Page Not Found</h2>
               <p>
                   Sorry, the page you're looking for couldn't be found
               </p>
           </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-blog\resources\views/errors/404.blade.php ENDPATH**/ ?>