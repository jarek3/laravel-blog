<?php if(isset($categoryName)): ?>
    <div class="alert alert-info">
        <p>Category: <strong><?php echo e($categoryName); ?></strong></p>
    </div>
<?php endif; ?>

<?php if(isset($tagName)): ?>
    <div class="alert alert-info">
        <p>Tagged: <strong><?php echo e($tagName); ?></strong></p>
    </div>
<?php endif; ?>

<?php if(isset($authorName)): ?>
    <div class="alert alert-info">
        <p>Author: <strong><?php echo e($authorName); ?></strong></p>
    </div>
<?php endif; ?>

<?php if($term=request('term')): ?>
    <div class="alert alert-info">
        <p>Search Results for: <strong><?php echo e($term); ?></strong></p>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\laravel-blog\resources\views/blog/alert.blade.php ENDPATH**/ ?>