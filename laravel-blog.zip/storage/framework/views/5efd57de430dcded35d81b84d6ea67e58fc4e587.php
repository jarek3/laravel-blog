<table class="table table-bordered">
    <thead>
    <tr>
        <td width="80">Action</td>
        <td>Tag Name</td>
        <td width="120">Post Count</td>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td>
                <?php echo Form::open(['method' => 'DELETE', 'route' => ['backend.tags.destroy', $tag->id]]); ?>

                <a href="<?php echo e(route('backend.tags.edit', $tag->id)); ?>" class="btn btn-xs btn-default">
                    <i class="fa fa-edit"></i>
                </a>

                <button onclick="return confirm('Are you sure?');" type="submit" class="btn btn-xs btn-danger">
                    <i class="fa fa-times"></i>
                </button>
                <?php echo Form::close(); ?>

            </td>
            <td><?php echo e($tag->name); ?></td>
            <td><?php echo e(($tmp = $tag->posts) ? $tmp->count() : 0); ?></td>
        </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\xampp\htdocs\laravel-blog\resources\views/backend/tags/table.blade.php ENDPATH**/ ?>