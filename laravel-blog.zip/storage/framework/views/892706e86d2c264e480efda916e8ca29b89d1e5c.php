<?php $__env->startSection('title', 'MyBlog | Edit category'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">

            <h1>
                Categories
                <small>Edit category</small>
            </h1>
            <ol class="breadcrumb">
                <li> <a href="<?php echo e(url('/home')); ?>"><i class="fa fa-dashboard"></i>Dashboard</a></li>
                <li> <a href="<?php echo e(route('backend.categories.index')); ?>">Categories</a></li>
                <li class="active">Edit Category</li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
                <?php echo Form::model($category,
                [
               'method'=>'PUT',
               'route' =>['backend.categories.update', $category->id],
               'files' => TRUE,
               'id' => 'post-form'
                ]); ?>


            <?php echo $__env->make('backend.categories.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php echo Form::close(); ?>


            </div>
            <!-- ./row -->
        </section>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

    <?php echo $__env->make('backend.blog.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<?php echo $__env->make('layouts.backend.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-blog\resources\views/backend/categories/edit.blade.php ENDPATH**/ ?>