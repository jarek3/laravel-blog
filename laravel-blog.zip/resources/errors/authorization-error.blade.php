<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Authorization Error</title>
</head>
<body>
<h1>You cannot delete default category!</h1>
<a href="javascript:window.history.back();">Go back</a>
</body>
</html>
